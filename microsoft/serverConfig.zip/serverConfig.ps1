configuration serverConfig 
{ 
    
    #Import-DscResource -ModuleName xActiveDirectory, xStorage, xNetworking, PSDesiredStateConfiguration, xPendingReboot
    Node localhost
    {
        Registry DisableUAC {
            Ensure = "Present"
            key = "HKLM:\Software\Microsoft\Windows\CurrentVersion\Policies\System"
            ValueName = "EnableLua"
            ValueData = "0"
            ValueType = "Dword"
        }

        Registry DisableServerManager {
            Ensure = "Present"
            key = "HKLM:\SOFTWARE\Policies\Microsoft\Windows\Server\ServerManager"
            ValueName = "DoNotOpenAtLogon"
            ValueData = "1"
            ValueType = "Dword"
        }
        Registry IEEnhancedSecurity {
            Ensure = "Present"
            key = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A7-37EF-4b3f-8CFC-4F3A74704073}"
            ValueName = "IsInstalled"
            ValueData = "0"
            ValueType = "Dword"
        }
        Registry IEEnhancedSecurity2 {
            Ensure = "Present"
            key = "HKLM:\SOFTWARE\Microsoft\Active Setup\Installed Components\{A509B1A8-37EF-4b3f-8CFC-4F3A74704073}"
            ValueName = "IsInstalled"
            ValueData = "0"
            ValueType = "Dword"
        }
        Registry DisableFirewall {
            Ensure = "Present"
            key = "HKLM:\SOFTWARE\Policies\Microsoft\WindowsFirewall\StandardProfile"
            ValueName = "EnableFirewall"
            ValueData = "0"
            ValueType = "Dword"
        }
        Registry DisableWindowsDefender {
            Ensure = "Present"
            key = "HKLM:\SOFTWARE\Policies\Microsoft\Windows Defender"
            ValueName = "DisableAntiSpyware"
            ValueData = "1"
            ValueType = "Dword"
        }
        Registry VisualEffect1 {
            Ensure = "Present"
            key = "HKCU:\Control Panel\Desktop"
            ValueName = "DragFullWindows"
            ValueData = "0"
            ValueType = "String"
        }
        Registry VisualEffect2 {
            Ensure = "Present"
            key = "HKCU:\Control Panel\Desktop"
            ValueName = "MenuShowDelay"
            ValueData = "0"
            ValueType = "String"
        }
        Registry VisualEffect4 {
            Ensure = "Present"
            key = "HKCU:\Control Panel\Desktop\WindowMetrics"
            ValueName = "MinAnimate"
            ValueData = "0"
            ValueType = "String"
        }
        Registry VisualEffect5 {
            Ensure = "Present"
            key = "HKCU:\Control Panel\Keyboard"
            ValueName = "KeyboardDelay"
            ValueData = "0"
            ValueType = "Dword"
        }
        Registry VisualEffect6 {
            Ensure = "Present"
            key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
            ValueName = "ListviewAlphaSelect"
            ValueData = "0"
            ValueType = "DWord"
        }
        Registry VisualEffect7 {
            Ensure = "Present"
            key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
            ValueName = "ListviewShadow"
            ValueData = "0"
            ValueType = "Dword"
        }
        Registry VisualEffect8 {
            Ensure = "Present"
            key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\Advanced"
            ValueName = "TaskbarAnimations"
            ValueData = "0"
            ValueType = "Dword"
        }
        Registry VisualEffect9 {
            Ensure = "Present"
            key = "HKCU:\Software\Microsoft\Windows\CurrentVersion\Explorer\VisualEffects"
            ValueName = "VisualFXSetting"
            ValueData = "3"
            ValueType = "Dword"
        }
        Registry VisualEffect10 {
            Ensure = "Present"
            key = "HKCU:\Software\Microsoft\Windows\DWM"
            ValueName = "EnableAeroPeek"
            ValueData = "0"
            ValueType = "Dword"
        }
        Registry LocalAccountTokenFilterPolicy {
            Ensure = "Absent"
            key = "HKLM:\SOFTWARE\Microsoft\Windows\CurrentVersion\Policies\System"
            ValueName = "LocalAccountTokenFilterPolicy"
            Force = $true
        }
   }
} 